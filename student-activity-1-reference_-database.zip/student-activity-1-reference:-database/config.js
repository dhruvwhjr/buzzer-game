import firebase from 'firebase';

const firebaseConfig = {
  apiKey: "AIzaSyCtmiF6dMWXw2IRa0kT99WsBps8MlBI4rY",
  authDomain: "quiz-buzzer-26927.firebaseapp.com",
  databaseURL: "https://quiz-buzzer-26927-default-rtdb.firebaseio.com",
  projectId: "quiz-buzzer-26927",
  storageBucket: "quiz-buzzer-26927.appspot.com",
  messagingSenderId: "590986348515",
  appId: "1:590986348515:web:f5bba0fa5425875f3542d6"
};


// Initialize Firebase
if(!firebase.apps.length){
  firebase.initializeApp(firebaseConfig);
}

export default  firebase.database()